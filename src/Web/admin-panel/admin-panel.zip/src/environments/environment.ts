export const environment = {
  production: false,
  apiUrl: 'https://localhost:7001/api/v1',
  hubUrl: 'https://localhost:7001/hubs',
  appName: 'MultiServices Admin',
  version: '1.0.0'
};
