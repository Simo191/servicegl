export const environment = {
  production: true,
  apiUrl: 'https://api.multiservices.ma/api/v1',
  hubUrl: 'https://api.multiservices.ma/hubs',
  appName: 'MultiServices Admin',
  version: '1.0.0'
};
